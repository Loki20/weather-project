const express = require('express');
const axios = require('axios');
const app = express();
app.get('/weather/:location', async (req, res) => {
  try {
    const { location } = req.params;
    const apiKey = '05728a978ed24372bb6133321232006';
    const apiUrl = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${location}`;

    const response = await axios.get(apiUrl);
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});
app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });
  

  